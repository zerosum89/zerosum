# Patchnote View Model Workflow v78

## 목적

v78은 `Patchnote View Model`을 기준 원천으로 삼아 패치노트 타임라인 HTML을 반복 생성하기 위한 최종 기준 문서 패키지입니다.

이 패키지는 과거 v65 결과를 그대로 복제하는 것이 아니라, v76에서 확정한 `본문 요약 → 일반 패치 요약` 표준 규칙을 기준으로 신규 패치노트에도 동일하게 적용 가능한 워크플로우를 정의합니다.

## 현재 기준 상태

| 항목 | 상태 |
|---|---:|
| 기준 DB | Patchnote View Model |
| 전체 이벤트 | 780 |
| 업데이트 이벤트 | 775 |
| 출시 이벤트 | 5 |
| 본문 요약 보유 | 775 |
| 일반 패치 요약 생성 | 775 |
| 주요 업데이트 요약 보유 | 124 |
| 레거시 DB1 필드 정리 | success |

## 포함 파일

| 파일 | 역할 |
|---|---|
| `README_WORKFLOW_v78.md` | 패키지 개요 |
| `patchnote_view_model_workflow_spec_v78.md` | 전체 워크플로우 정의 |
| `patchnote_view_model_field_schema_v78.md` | Patchnote View Model 필드 기준 |
| `body_summary_standard_v78.md` | 본문 요약 생성 기준 |
| `general_patch_summary_rule_spec_v78.md` | 일반 패치 요약 표준 생성 규칙 |
| `new_patchnote_runbook_v78.md` | 신규 패치노트 추가 시 작업 순서 |
| `final_state_audit_v78.json` | 최종 상태 요약 |
| `index-2_view_model_v76_standard_general.html` | 현재 최종 HTML 기준본 |
| `timeline_data_view_model_v76_standard_general.json` | 현재 최종 타임라인 JSON 기준본 |
| `export_audit_v76_standard_general.json` | v76 생성 감사 결과 |
| `legacy_cleanup_v77_20260531_170953.json` | v77 레거시 필드 정리 로그 |

## 운영 원칙

1. DB1/DB2는 더 이상 참조하지 않습니다.
2. `본문 요약`은 Patchnote View Model의 실제 필드로 유지합니다.
3. `일반 패치 요약`은 DB 필드가 아니라 HTML/export 단계의 파생값으로 생성합니다.
4. `원문 요약`은 당장 삭제하지 않고 보존합니다.
5. 레거시 추적 필드는 제거 완료 상태를 기준으로 합니다.
