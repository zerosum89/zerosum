# Patchnote View Model Workflow Spec v78

## 1. 기준 방향

패치노트 타임라인은 `Patchnote View Model`을 단일 기준 DB로 사용합니다.  
원문 수집본, DB1, DB2는 신규 HTML 생성의 직접 원천으로 사용하지 않습니다.

```txt
Patchnote View Model
→ export
→ body_summary 사용
→ general_patch_summary 파생 생성
→ timeline_data.json 생성
→ HTML 렌더링
```

## 2. 데이터 역할

| 데이터 | 역할 | 저장 위치 |
|---|---|---|
| 실제 패치일 | 타임라인 배치 기준 | Patchnote View Model |
| 게임명 | 게임 row 기준 | Patchnote View Model |
| 패치노트 제목 | 카드 제목 | Patchnote View Model |
| 원문 URL | 원문 이동 링크 | Patchnote View Model |
| 카드 요약 | 카드 내 headline | Patchnote View Model |
| 주요 업데이트 요약 | 대형 변화 headline | Patchnote View Model |
| 대표 핵심 신호 | 대형 변화 badge | Patchnote View Model |
| 본문 요약 | 상세 패널 핵심 설명 | Patchnote View Model |
| 일반 패치 요약 | 상위 분류 태그 | export/build 단계 파생 |

## 3. HTML 상세 패널 구조

상세 패널은 아래 순서를 표준으로 합니다.

```txt
대표 핵심 신호
주요 업데이트
본문 요약
일반 패치 요약
원문 패치노트 열기
```

## 4. 본문 요약과 일반 패치 요약의 역할 분리

| 항목 | 역할 |
|---|---|
| 본문 요약 | 패치 내용을 2~4줄로 구체 설명 |
| 일반 패치 요약 | 패치 성격을 1~3개 상위 분류로 빠르게 스캔 |
| 주요 업데이트 요약 | 신규 클래스, 신규 대형 콘텐츠, 신규 성장축, 서버/경제 구조 변화 등 headline |

## 5. 최종 상태

| 항목 | 결과 |
|---|---:|
| 업데이트 이벤트 | 775 |
| 본문 요약 | 775 |
| 일반 패치 요약 | 775 |
| 주요 업데이트 요약 | 124 |
| 레거시 삭제 필드 | 원본 DB1 Page ID, 원본 DB1 URL, 원문 해시 |

## 6. 버전 기준

| 버전 | 의미 |
|---|---|
| v65 | 본문 요약 보강 기준본 |
| v68 | 최종 UI 검수본 |
| v69~v71 | 본문 요약 Notion 적재 |
| v72~v73 | Notion export 기반 HTML 재생성 검증 |
| v76 | 일반 패치 요약 표준 파생 규칙 확정 |
| v77 | 레거시 필드 정리 |
| v78 | 워크플로우 문서화 기준본 |
